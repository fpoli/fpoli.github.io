#![allow(unused_variables, unused_imports, dead_code)]
use prusti_contracts::*;

pub struct List {
    pub value: u32,
    next: Option<Box<List>>,
}

impl List {
    #[pure]
    pub fn len(&self) -> u32 {
        1 + match self.next {
            Some(ref tail) => tail.len(),
            None => 0
        }
    }

    #[pure]
    #[requires(n < self.len())]
    pub fn at(&self, n: u32) -> u32 {
        if n == 0 {
            self.value
        } else {
            match self.next {
                Some(ref tail) => tail.at(n - 1),
                None => unreachable!()
            }
        }
    }

    #[pure]
    pub fn is_sorted(&self) -> bool {
        if let Some(ref tail) = self.next {
            self.value <= tail.value && tail.is_sorted()
        } else {
            true
        }
    }
}

#[requires(x.is_sorted())]
#[requires(v < x.value)]
#[ensures(result.is_sorted())]
pub fn prepend(x: List, v: u32) -> List {
    List { value: v, next: Some(Box::new(x)) }
}
