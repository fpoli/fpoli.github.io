#![allow(unused_variables, unused_imports, dead_code)]
use prusti_contracts::*;

pub struct List {
    pub value: u32,
    next: Option<Box<List>>,
}

impl List {
    /*
    #[ensures(self.value == old(self.value))]
    pub fn len(&mut self) -> u32 {
        1 + match self.next {
            Some(ref mut tail) => tail.len(),
            None => 0
        }
    }
    */

    #[pure]
    pub fn len(&self) -> u32 {
        1 + match self.next {
            Some(ref tail) => tail.len(),
            None => 0
        }
    }
}

pub fn client(x: &mut List) {
    let value = x.value;
    let length = x.len();
    let again_value = x.value;
    let again_length = x.len();
    assert!(value == again_value);
    assert!(length == again_length);
}
