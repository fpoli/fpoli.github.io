use prusti_contracts::*;

/// A monotonically strictly increasing discrete function, with domain [0, domain_size)
pub trait Function {
    fn domain_size(&self) -> usize;
    fn eval(&self, x: usize) -> i32;
}

/// Find the unique `x` s.t. `f(x) == target`
pub fn bisect<T: Function>(f: &T, target: i32) -> Option<usize> {
    let mut low = 0;
    let mut high = f.domain_size();
    while low < high {
        // let mid = (low + high) / 2; // Bad
        let mid = low + ((high - low) / 2); // Good
        let mid_val = f.eval(mid);
        if mid_val < target {
            low = mid + 1;
        } else if mid_val > target {
            high = mid;
        } else {
            return Some(mid)
        }
    }
    None
}
